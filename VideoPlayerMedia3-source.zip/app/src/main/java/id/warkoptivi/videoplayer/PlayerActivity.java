package id.warkoptivi.videoplayer;

import android.app.*;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.*;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import java.util.Locale;

public class PlayerActivity extends AppCompatActivity {
    private ExoPlayer player;
    private PlayerView playerView;
    private TextView title, clock, timeLabel;
    private SeekBar seek;
    private LinearLayout controls;
    private boolean locked = false, controlsVisible = true, seeking = false;
    private int resizeMode = 0; // Fit, Fill, Zoom, Full
    private final String[] resizeNames = {"Fit", "Fill", "Zoom", "Full"};
    private AudioManager audioManager;
    private float savedVolume = 1f;
    private HandlerTick tick;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        audioManager = (AudioManager)getSystemService(AUDIO_SERVICE);
        buildUi();
        Uri uri = getIntentUri(getIntent());
        if (uri != null) playUri(uri);
        else {
            title.setText("Video Player");
            Toast.makeText(this, "Buka video dari aplikasi lain atau pilih URL streaming.", Toast.LENGTH_LONG).show();
        }
        tick = new HandlerTick();
        tick.run();
    }

    private Uri getIntentUri(Intent i) {
        if (i == null) return null;
        Uri u = i.getData();
        if (u != null) return u;
        if (Intent.ACTION_SEND.equals(i.getAction())) {
            Object x = i.getParcelableExtra(Intent.EXTRA_STREAM);
            if (x instanceof Uri) return (Uri)x;
            String text = i.getStringExtra(Intent.EXTRA_TEXT);
            if (text != null && (text.startsWith("http://") || text.startsWith("https://"))) return Uri.parse(text.trim());
        }
        return null;
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable bg(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(28));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(Color.WHITE);
        t.setTextSize(size); t.setGravity(Gravity.CENTER); t.setFocusable(true);
        return t;
    }
    private TextView button(String s, int size, Runnable action) {
        TextView t = text(s, size); t.setPadding(dp(12), dp(8), dp(12), dp(8));
        t.setBackground(bg(0xCC202124, 0x66FFFFFF));
        t.setOnClickListener(v -> action.run());
        t.setOnFocusChangeListener((v, has) -> t.setBackground(bg(has ? 0xFF41464D : 0xCC202124, has ? Color.WHITE : 0x66FFFFFF)));
        return t;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        playerView = new PlayerView(this);
        playerView.setUseController(false);
        playerView.setKeepContentOnPlayerReset(true);
        playerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT);
        root.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        playerView.setOnClickListener(v -> toggleControls());

        // Top title and close/back button
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(16), dp(10), dp(16), dp(10));
        top.setBackgroundColor(0x99000000);
        title = text("Video Player", 16); title.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        clock = text("●", 14); top.addView(clock);
        TextView close = button("✕", 20, this::finish);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(48), dp(48)); cp.leftMargin = dp(12);
        top.addView(close, cp);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(top, tp);

        // Bottom playback controls
        controls = new LinearLayout(this); controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(14), dp(10), dp(14), dp(14));
        controls.setBackgroundColor(0xB8000000);
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        addButton(row, "🔉", 44, () -> changeVolume(-0.1f));
        addButton(row, "↶ 10", 58, () -> seekBy(-10000));
        addButton(row, "Ⅱ", 54, () -> { if (player != null) { if (player.isPlaying()) player.pause(); else player.play(); refreshPlayButton(); } });
        addButton(row, "10 ↷", 58, () -> seekBy(10000));
        Space spacer = new Space(this); row.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1));
        addButton(row, "Fit", 50, this::cycleResize);
        addButton(row, "CC", 44, this::showSubtitleOptions);
        addButton(row, "🔒", 44, this::toggleLock);
        controls.addView(row);
        seek = new SeekBar(this); seek.setMax(1000);
        controls.addView(seek, new LinearLayout.LayoutParams(-1, dp(28)));
        timeLabel = text("00:00 / 00:00", 12);
        timeLabel.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        controls.addView(timeLabel);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean user) {
                if (user && player != null && player.getDuration() > 0) {
                    timeLabel.setText(fmt(player.getDuration() * p / 1000) + " / " + fmt(player.getDuration()));
                }
            }
            public void onStartTrackingTouch(SeekBar b) { seeking = true; }
            public void onStopTrackingTouch(SeekBar b) {
                if (player != null && player.getDuration() > 0) player.seekTo(player.getDuration() * b.getProgress() / 1000);
                seeking = false;
            }
        });
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(controls, bp);
        setContentView(root);
    }

    private void addButton(LinearLayout row, String label, int widthDp, Runnable action) {
        TextView b = button(label, 15, action);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(widthDp), dp(44));
        p.setMargins(dp(4), dp(3), dp(4), dp(3)); row.addView(b, p);
    }

    private void playUri(Uri uri) {
        try {
            if (player != null) player.release();
            player = new ExoPlayer.Builder(this).build();
            playerView.setPlayer(player);
            MediaItem item = MediaItem.fromUri(uri);
            player.setMediaItem(item);
            player.prepare();
            player.play();
            String name = uri.getLastPathSegment();
            if (name == null || name.trim().isEmpty()) name = uri.toString();
            title.setText(name);
            player.addListener(new Player.Listener() {
                @Override public void onPlaybackStateChanged(int state) {
                    if (state == Player.STATE_ENDED) refreshPlayButton();
                }
                @Override public void onIsPlayingChanged(boolean isPlaying) { refreshPlayButton(); }
                @Override public void onPlayerError(PlaybackException error) {
                    Toast.makeText(PlayerActivity.this, "Video gagal diputar: " + error.getErrorCodeName(), Toast.LENGTH_LONG).show();
                }
            });
        } catch (Exception e) {
            Toast.makeText(this, "Tidak dapat membuka video.", Toast.LENGTH_LONG).show();
        }
    }

    private void refreshPlayButton() {
        // Controls are built with simple text buttons; keyboard/media controls still work.
    }
    private void seekBy(long ms) { if (player != null) player.seekTo(Math.max(0, player.getCurrentPosition() + ms)); }
    private void changeVolume(float delta) {
        if (player == null) return;
        savedVolume = Math.max(0f, Math.min(1f, player.getVolume() + delta));
        player.setVolume(savedVolume);
    }
    private void cycleResize() {
        resizeMode = (resizeMode + 1) % 4;
        int mode;
        switch (resizeMode) {
            case 1: mode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL; break;
            case 2: mode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM; break;
            case 3: mode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT; break;
            default: mode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT;
        }
        playerView.setResizeMode(mode);
        Toast.makeText(this, resizeNames[resizeMode], Toast.LENGTH_SHORT).show();
    }
    private void showSubtitleOptions() {
        if (player == null) return;
        androidx.media3.common.TrackSelectionParameters p = player.getTrackSelectionParameters();
        boolean enabled = p.trackTypeDisabled(C.TRACK_TYPE_TEXT);
        player.setTrackSelectionParameters(p.buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !enabled).build());
        Toast.makeText(this, enabled ? "Subtitle diaktifkan jika tersedia" : "Subtitle dimatikan", Toast.LENGTH_SHORT).show();
    }
    private void toggleLock() {
        locked = !locked;
        controls.setVisibility(locked ? View.GONE : View.VISIBLE);
        Toast.makeText(this, locked ? "Kontrol dikunci — ketuk layar untuk membuka" : "Kontrol dibuka", Toast.LENGTH_SHORT).show();
    }
    private void toggleControls() {
        if (locked) { locked = false; controls.setVisibility(View.VISIBLE); return; }
        controlsVisible = !controlsVisible;
        controls.setVisibility(controlsVisible ? View.VISIBLE : View.GONE);
    }
    private String fmt(long ms) {
        long sec = Math.max(0, ms / 1000);
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", sec/3600, (sec%3600)/60, sec%60).replaceFirst("^00:", "");
    }
    private class HandlerTick implements Runnable {
        public void run() {
            if (player != null && !seeking) {
                long dur = player.getDuration(), pos = player.getCurrentPosition();
                if (dur > 0) seek.setProgress((int)Math.min(1000, pos * 1000 / dur));
                timeLabel.setText(fmt(pos) + " / " + (dur > 0 ? fmt(dur) : "--:--"));
            }
            clock.setText(new java.text.SimpleDateFormat("HH:mm", Locale.getDefault()).format(new java.util.Date()));
            playerView.postDelayed(this, 500);
        }
    }
    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (player != null) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                    if (player.isPlaying()) player.pause(); else player.play(); return true;
                case KeyEvent.KEYCODE_DPAD_LEFT: seekBy(-10000); return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT: seekBy(10000); return true;
                case KeyEvent.KEYCODE_MEDIA_PLAY: player.play(); return true;
                case KeyEvent.KEYCODE_MEDIA_PAUSE: player.pause(); return true;
            }
        }
        if (keyCode == KeyEvent.KEYCODE_BACK) { finish(); return true; }
        return super.onKeyDown(keyCode, event);
    }
    @Override protected void onDestroy() {
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }
}
