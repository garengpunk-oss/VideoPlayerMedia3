VIDEO PLAYER MEDIA3 - PETUNJUK BUILD DARI HP ANDROID

Isi:
- Proyek Android Java + AndroidX Media3 ExoPlayer 1.11.1
- Pemutaran URL yang dikirim lewat Intent, termasuk dukungan HLS lewat modul media3-exoplayer-hls
- Tombol mundur/maju 10 detik, play/pause, volume aplikasi, subtitle on/off, mode ukuran, progress bar
- Workflow GitHub Actions untuk membangun APK secara online

BUILD APK DARI HP:
1. Buka https://github.com/ di browser HP dan login/daftar.
2. Buat repository baru, misalnya VideoPlayerMedia3. Pilih Public atau Private, lalu Create repository.
3. Upload semua isi folder proyek ini ke repository, jangan upload folder induk VideoPlayerMedia3 sebagai satu folder bersarang. Pastikan .github/workflows/build-apk.yml ikut terunggah.
4. Buka tab Actions di repository. Jika diminta, tekan "I understand my workflows, go ahead and enable them".
5. Pilih workflow "Build Android APK", tekan "Run workflow", lalu tombol hijau "Run workflow".
6. Tunggu hingga workflow selesai dengan tanda centang hijau.
7. Buka hasil workflow yang sukses, cari bagian Artifacts, lalu unduh "VideoPlayer-debug-apk".
8. Ekstrak ZIP artifact, lalu pasang app-debug.apk di Android. Jika diminta, izinkan browser menginstal aplikasi dari sumber tersebut.

CARA MENGUJI:
- Buka APK dari aplikasi video/browser yang menyediakan "Open with / Buka dengan" dan pilih Video Player.
- Atau coba URL HLS yang memang kamu punya izin untuk akses.
- File lokal dapat dibuka lewat aplikasi pengelola file yang mengirim Intent video/*.

CATATAN PENTING:
- Ini source code awal (starter), belum diuji dengan build nyata dalam lingkungan Android di sini.
- Beberapa aplikasi browser tidak mengirim URL video ke pemutar eksternal, sehingga opsi "Buka dengan" bisa tidak muncul.
- Dukungan URL HLS bergantung pada server, header/cookie, jaringan, dan codec.
- Tombol "Full" saat ini adalah pilihan Fit-like untuk menjaga rasio gambar; mode full-stretch non-proporsional perlu implementasi lanjutan.
- Tampilan ini merupakan versi dasar, belum tiruan piksel demi piksel dari screenshot. Ikon dan kontrol bisa disempurnakan setelah APK berhasil dibangun dan diuji.
- Belum ada pemilih playlist M3U, daftar kanal, resume posisi tersimpan, pengaturan kecepatan, pemilih track audio, dan sinkronisasi subtitle. Fitur tersebut bisa ditambahkan bertahap setelah build dasar berhasil.
